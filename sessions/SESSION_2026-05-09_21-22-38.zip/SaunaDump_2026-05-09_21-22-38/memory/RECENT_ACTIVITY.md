---
contract: "System-managed file containing recent user activity. Data is injected automatically; the agent should not edit this file directly. Use this context to maintain continuity across sessions."
short_description: "Today and yesterday"
---

[Injected automatically]
