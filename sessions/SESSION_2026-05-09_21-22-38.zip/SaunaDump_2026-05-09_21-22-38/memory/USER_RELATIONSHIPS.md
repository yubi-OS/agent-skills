---
contract: "People in the user's life with per-person dossiers. Route here when: a person is mentioned with enough context to create or update an entry (role, relationship, status, or significant event). One entry per person, no duplicates across sections. Editing: only update on significant changes (role shifts, trust changes, departures, major events), not routine mentions. Never remove entries; move departed people to the departed section with date and reason. Trust level is user-assigned, never rate people yourself. If a person is mentioned but only in the context of a fact about the user ('my brother lives in Paris'), the relationship goes here and the user fact goes in USER_PROFILE."
short_description: "People in your work and life"
---

## Work

### [Name]
- Role:
- Context:
- Trust level: /5
- Dynamic:
- Notes:

[Sauna will update this]

## Personal

### [Name]
- Relationship:
- Context:
- Dynamic:

[Sauna will update this]

## Advisors

### [Name]
- Expertise:
- How they help:

[Sauna will update this]

## Departed

### [Name]
- Former role:
- Departed: [date]
- Reason:

[Sauna will update this]
