---
contract: "Tools, software, services, and communication channels the user uses, and how they prefer to use them; plus what Sauna can do for them in the product (integrations, automations, connected surfaces). Route here when: the user describes how they use a tool, expresses a preference about it, reveals a workflow connecting tools, indicates which communication channels they use for which audiences, or clarifies Sauna capabilities (what to connect, what to automate, scope). A casual mention of a tool isn't enough — there needs to be context about how or why they use it. Editing: one line per tool or capability note. If an entry is already listed, tighten the existing line rather than adding a duplicate. Implementation details, API patterns, and automation recipes belong in Skills, not here. Account information belongs here."
short_description: "Tools and apps you use"
---

## Software & Apps

- [Tool]: [purpose, how they use it, preferences]

[Sauna will update this]

## Services & Accounts

- [Service]: [account, usage]

[Sauna will update this]

## Communication Channels

- [Channel]: [who/what it's used for]

[Sauna will update this]

## Workflows

- [Trigger] → [Action]: [tools involved]

[Sauna will update this]

## Sauna Capabilities

- When working with meeting notes, Sauna allows Granola access via MCP or (for enterprise customers only) supports the Granola API.
