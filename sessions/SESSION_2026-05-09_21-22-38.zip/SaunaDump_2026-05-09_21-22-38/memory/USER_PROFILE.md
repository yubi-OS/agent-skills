---
contract: "Stable facts about the user: identity, background, work, interests, values, goals, communication style, strengths, blind spots, stressors, and motivations. Only record what the user has explicitly stated or confirmed, never infer. Route here when: user shares biographical facts, career details, personal interests, thinking patterns, goals, what energizes or drains them, how they communicate, or self-identified strengths and weaknesses. Editing: fill empty fields when learned, append to existing content. If a fact is about another person, it belongs in USER_RELATIONSHIPS. If it's about how the user wants the agent to behave, it belongs in USER_PREFERENCES. Episodic details ('we discussed X today') don't belong here; extract the stable fact behind them. Information about the user's tools and services (account names, etc.) belongs in SAUNA_TOOLS."
short_description: "About you: background, work, interests"
---

## Basics

- Name: [Sauna will update this]
- Age: [Sauna will update this]
- Location: [Sauna will update this]
- Timezone: [Sauna will update this]
- Languages: [Sauna will update this]

## Work

- Company: [Sauna will update this]
- Role: [Sauna will update this]
- Building: [Sauna will update this]
- Stage: [Sauna will update this]
- Team size: [Sauna will update this]

## Current Focus

[Sauna will update this]

## Background

- Career path: [Sauna will update this]
- Education: [Sauna will update this]
- Notable experience: [Sauna will update this]

## Personal

- Interests: [Sauna will update this]
- Hobbies: [Sauna will update this]
- Routines: [Sauna will update this]
- Energy patterns: [Sauna will update this]

## Communication Style

- Verbose vs. terse: [Sauna will update this]
- Visual vs. verbal: [Sauna will update this]
- Async vs. sync: [Sauna will update this]

## How They Think

- Decision style: [Sauna will update this]
- Values: [Sauna will update this]
- Risk tolerance: [Sauna will update this]
- Conflict approach: [Sauna will update this]

## Strengths

[Sauna will update this]

## Blind Spots

[Sauna will update this]

## Stressors & Signals

[Sauna will update this]

## Motivations

[Sauna will update this]

## Goals

[Sauna will update this]

## Key Quotes

[Sauna will update this]
