# GitHub PR Snapshot — May 9, 2026

> **Account:** `corning-croak-cable`  
> **Repos with access:** `corning-croak-cable/agent-skills` (fork of `addyosmani/agent-skills`), `corning-croak-cable/particleos`  
> **Note:** No personal authored PRs or commits found in the last 14 days. Report reflects open PR activity in the upstream `addyosmani/agent-skills` repo — the live project your fork tracks.

---

## PR Status Table

| # | Repo | Title | Author | Status | Days Open | Your Action |
|---|------|--------|--------|--------|-----------|-------------|
| [#159](https://github.com/addyosmani/agent-skills/pull/159) | agent-skills | docs: clarify README skill count | MiladZarour | Ready | 0 | Review |
| [#157](https://github.com/addyosmani/agent-skills/pull/157) | agent-skills | fix: SKILL.md files reference non-existent scripts | andoan16 | Ready | 0 | Review |
| [#156](https://github.com/addyosmani/agent-skills/pull/156) | agent-skills | fix: Add Hermes Agent integration docs | andoan16 | Ready | 0 | Review |
| [#155](https://github.com/addyosmani/agent-skills/pull/155) | agent-skills | fix: plugin.json version mismatch (1.0.0 vs 0.6.0) | andoan16 | Ready | 0 | Review |
| [#154](https://github.com/addyosmani/agent-skills/pull/154) | agent-skills | fix: /build cannot trigger git | andoan16 | Ready | 0 | Review |
| [#149](https://github.com/addyosmani/agent-skills/pull/149) | agent-skills | feat: register 5 premium governance skills | enriquekalven | Ready | 1 | Review |
| [#148](https://github.com/addyosmani/agent-skills/pull/148) | agent-skills | Create SECURITY.md for security policy | sidansaidneu-web | Ready | 1 | Review |
| [#147](https://github.com/addyosmani/agent-skills/pull/147) | agent-skills | Create SECURITY.mdz (possible duplicate of #148) | sidansaidneu-web | Ready | 1 | Comment |
| [#144](https://github.com/addyosmani/agent-skills/pull/144) | agent-skills | docs: add Chinese (zh-CN) README translation | isagoakira | Ready | 2 | Review |
| [#141](https://github.com/addyosmani/agent-skills/pull/141) | agent-skills | ci: add markdown lint baseline for skills | aqilaziz | Ready | 2 | Review |
| [#134](https://github.com/addyosmani/agent-skills/pull/134) | agent-skills | docs: modernize Windsurf integration with Rules engine | juanitourquiza | Ready | 2 | Review |
| [#131](https://github.com/addyosmani/agent-skills/pull/131) | agent-skills | docs: add Code of Conduct | zichen0116 | Ready | 2 | Review |
| [#129](https://github.com/addyosmani/agent-skills/pull/129) | agent-skills | Add prompt-injection-defense skill (OWASP LLM01) | everybitcounts | Ready | 4 | Review |
| [#128](https://github.com/addyosmani/agent-skills/pull/128) | agent-skills | Fix formatting in README workflow diagram | kigiri | Ready | 4 | Approve |
| [#127](https://github.com/addyosmani/agent-skills/pull/127) | agent-skills | docs: add Spanish translations for all skills | juanitourquiza | Ready | 4 | Review |
| [#120](https://github.com/addyosmani/agent-skills/pull/120) | agent-skills | docs: add Chinese translations for all skills | MengZ-super | Ready | 7 | Review |
| [#105](https://github.com/addyosmani/agent-skills/pull/105) | agent-skills | Add autonomous-code-improvement skill | telivity-otaip | Ready (review req → addyosmani) | 14 | Comment |
| [#88](https://github.com/addyosmani/agent-skills/pull/88) | agent-skills | feat: add Codex plugin support without duplicating skills | federicobartoli | Ready | 20 | Comment |
| [#65](https://github.com/addyosmani/agent-skills/pull/65) | agent-skills | docs: Add Copilot CLI setup documentation | juangcarmona | Ready | 26 | Review |
| [#62](https://github.com/addyosmani/agent-skills/pull/62) | agent-skills | Wire agent personas into their corresponding skills | googlarz | Ready (review req → addyosmani) | 28 | Watch |

---

## ⚡ Quick Wins — 3 PRs to act on today

**1. [#128](https://github.com/addyosmani/agent-skills/pull/128) — Fix formatting in README workflow diagram** (kigiri, 4 days open)  
Pure formatting fix, no logic changes. Low risk, easy to verify visually. Approve or comment with a thumbs up to unblock.

**2. [#131](https://github.com/addyosmani/agent-skills/pull/131) — docs: add Code of Conduct** (zichen0116, 2 days open)  
Standard community hygiene doc. No technical risk. Should be a near-instant approval for any active contributor.

**3. [#159](https://github.com/addyosmani/agent-skills/pull/159) — docs: clarify README skill count** (MiladZarour, 0 days old)  
Opened today. One-liner docs fix. If the README count is actually off, this is immediately useful to ship.

---

## 🔍 Code Patterns — 3 things from recent commits

**1. Docs-first, internationalization push**  
The overwhelming share of open PRs (and several recent merges) are documentation: Chinese README, Spanish translations, Cursor/Windsurf/Copilot/OpenCode setup guides. The project is clearly past early-adopter phase and is scaling to a broader international developer audience. The code barely changed in 2 weeks; the community is writing the docs.

**2. Plugin/integration plumbing being debugged in public**  
Four commits in the last 14 days touched `plugin.json` — arrays vs. objects for skill declarations, HTTPS vs. SSH install URLs, directory-form skill auto-discovery. The plugin system launched before its schema was fully stable and contributors are patching it commit by commit. Expect more churn here.

**3. Hooks and session-start reliability was a real problem**  
Two PRs merged this week directly addressed `session-start` JSON regressions (#132 fixed a bug, #141 adds a CI markdown lint baseline). A separate commit added explicit test coverage for the hook output schema. This pattern — bug → fix → test, in three separate PRs from three different people — signals the test surface was thin before and the community is now adding safety nets retroactively.

---

## 🚧 Blocked Work — Stalled PRs (>3 days)

| # | Title | Days Stalled | Why Blocked | Suggested Action |
|---|-------|-------------|-------------|-----------------|
| [#62](https://github.com/addyosmani/agent-skills/pull/62) | Wire agent personas into their corresponding skills | 28 | Review explicitly requested from `addyosmani`; no response | Ping author — ask if they need a secondary reviewer while addyosmani is busy |
| [#105](https://github.com/addyosmani/agent-skills/pull/105) | Add autonomous-code-improvement skill | 14 | Review explicitly requested from `addyosmani` | Same — comment with your assessment to give maintainer a head start |
| [#88](https://github.com/addyosmani/agent-skills/pull/88) | feat: add Codex plugin support without duplicating skills | 20 | No reviewers assigned; last updated May 8 (probably rebased) | Read the diff — this is a feature overlap with the main plugin system. Comment on whether it conflicts with how `plugin.json` works post-#114 |
| [#120](https://github.com/addyosmani/agent-skills/pull/120) | docs: add Chinese translations for all skills | 7 | No reviewers; large scope (all skills + docs) | Scope is big enough to need a native speaker sign-off. Comment asking for a Chinese-speaking reviewer if addyosmani can't prioritize it this week |
| [#65](https://github.com/addyosmani/agent-skills/pull/65) | docs: Add Copilot CLI setup documentation | 26 | No reviewers despite recent activity (updated May 7) | Old PR, recently poked — just needs eyes. Read the diff and approve or request changes |

---

*Generated: 2026-05-09 · GitHub account: corning-croak-cable · Upstream repo: addyosmani/agent-skills*
