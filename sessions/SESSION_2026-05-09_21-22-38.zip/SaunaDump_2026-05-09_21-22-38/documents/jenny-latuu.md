# Jenny Latuu

## Summary

New to Sauna — profile data is sparse at the moment. Jenny uses a Duck.com privacy email, suggesting some preference for digital privacy. No public professional footprint was found under this name. The profile will fill in as Jenny shares more context.

## What We Know

- **Name**: Jenny Latuu
- **Email**: tripping-opal-wolf@duck.com (Duck.com anonymous email — privacy-conscious)
- **Public footprint**: No LinkedIn or professional profile found under "Jenny Latuu"

## Likely Working Style (inferred from thin signal)

- Privacy-aware: using a Duck.com alias rather than a personal or work email suggests some intentionality around data hygiene
- Possibly independent or early in exploring AI tools — no professional context shared at onboarding

## Open Questions

- What does Jenny do for work? (role, company, industry)
- Where is she based?
- What's she hoping to use Sauna for?

---
*Last updated: May 9, 2026. Enrich as more context emerges.*
