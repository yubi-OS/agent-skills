# yubios Launch Plan

**Launch date:** Thursday, June 4, 2026
**Lead angle:** YubiKey as the only root of trust — full stack, no TPM
**Repo:** https://github.com/corning-croak-cable/yubios

---

## Phase 0: Foundation (May 9–16)

| Date | Task | Owner | Status |
|------|------|-------|--------|
| May 9 | Kick off PR plan, confirm launch date | Jenny | ✅ Done |
| May 9 | PR skill + all assets drafted | Sauna | ✅ Done |
| May 12 | README audit: answers what/why/how/trust | Jenny | ⬜ |
| May 13 | README renders cleanly, no broken links | Jenny | ⬜ |
| May 14 | Review all drafted assets, request edits | Jenny | ⬜ |
| May 16 | Lock final messaging for both audiences | Jenny | ⬜ |

**README must answer these 4 questions before anything else ships:**
1. What does this do? (one sentence)
2. Why not TPM? (two sentences)
3. How do I try it in 5 minutes? (step-by-step)
4. How do I trust this? (link to ADRs + source citations)

---

## Phase 1: Build & Brief (May 17–23)

| Date | Task | Owner | Status |
|------|------|-------|--------|
| May 17 | Draft technical deep-dive post (LWN/blog) | Jenny | ⬜ |
| May 20 | Identify and brief 2-3 trusted community members | Jenny | ⬜ |
| May 21 | Share early repo access with community contacts | Jenny | ⬜ |
| May 23 | Send press pitches (embargoed until June 4) | Jenny | ⬜ |
| May 23 | Phoronix, LWN, The Register pitches sent | Jenny | ⬜ |

**Community seeding targets** (fill in actual names):
- Contact 1: _____ (r/netsec moderator / respected contributor)
- Contact 2: _____ (Linux security researcher / blogger)
- Contact 3: _____ (FIDO Alliance community member)

---

## Phase 2: Pre-Launch (May 24–June 3)

| Date | Task | Owner | Status |
|------|------|-------|--------|
| May 24 | Embargo window opens — press Q&A available | Jenny | ⬜ |
| May 28 | Deep-dive post final draft complete | Jenny | ⬜ |
| May 30 | Follow up on unanswered press pitches | Jenny | ⬜ |
| May 31 | Final pre-launch repo check (README, links, license) | Jenny | ⬜ |
| June 1 | Confirm repo is public and renders cleanly | Jenny | ⬜ |
| June 2 | All social posts scheduled or queued | Jenny | ⬜ |
| June 3 | Community contacts confirmed and ready | Jenny | ⬜ |
| June 3 | Launch day briefing: confirm timing (9 AM ET) | Jenny | ⬜ |

---

## Phase 3: Launch Day (June 4)

**Sequence is critical. Follow this order.**

| Time (ET) | Action | Status |
|-----------|--------|--------|
| 9:00 AM | HN "Show HN" post live | ⬜ |
| 9:15 AM | Social thread live (Twitter/X, Mastodon, Bluesky) | ⬜ |
| 9:30 AM | Lobste.rs submission | ⬜ |
| 10:00 AM | r/netsec post | ⬜ |
| 10:30 AM | r/linux post | ⬜ |
| 11:00 AM | Press pitch email to Ars Technica (tips form) | ⬜ |
| 12:00 PM | r/privacy post | ⬜ |
| 12:30 PM | r/yubikey post | ⬜ |
| All day | Monitor HN comments, reply within 2 hours | ⬜ |
| All day | Monitor Reddit threads, reply within 2 hours | ⬜ |

**Do NOT:**
- Cross-post to multiple subreddits simultaneously (flag risk)
- Go silent after posting — the first 4 hours make or break a launch

---

## Phase 4: Post-Launch (June 5–14)

| Date | Task | Owner | Status |
|------|------|-------|--------|
| June 5 | Engage all HN and Reddit comments | Jenny | ⬜ |
| June 5–6 | Follow up with press who haven't published | Jenny | ⬜ |
| June 7 | Log all coverage in `documents/pr/coverage.md` | Jenny | ⬜ |
| June 9 | Publish technical deep-dive post | Jenny | ⬜ |
| June 10 | Submit to TLDR Newsletter | Jenny | ⬜ |
| June 10 | Submit to Console.dev | Jenny | ⬜ |
| June 11 | Email The Changelog with pitch | Jenny | ⬜ |
| June 12 | Post to FIDO Alliance community forum | Jenny | ⬜ |
| June 14 | 10-day retrospective: what worked, what to do differently | Jenny | ⬜ |

---

## Key Assets

| Asset | File | Status |
|-------|------|--------|
| HN post | `documents/pr/assets/hn-post.md` | ✅ Draft |
| Reddit r/netsec | `documents/pr/assets/reddit-netsec.md` | ✅ Draft |
| Reddit r/privacy | `documents/pr/assets/reddit-privacy.md` | ✅ Draft |
| Press pitch | `documents/pr/assets/press-pitch.md` | ✅ Draft |
| Social thread | `documents/pr/assets/social-thread.md` | ✅ Draft |
| Coverage log | `documents/pr/coverage.md` | ✅ Ready |

---

## Success Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| HN front page | Yes (top 30) | — |
| HN points at 24h | >200 | — |
| GitHub stars at 48h | >500 | — |
| Reddit posts | 4 subreddits | — |
| Press coverage | 2+ outlets | — |
| Deep-dive post published | June 9 | — |
