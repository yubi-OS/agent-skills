# Reddit Post: r/netsec

**Subreddit:** r/netsec
**Post timing:** June 4, 2026 — 30 min after HN goes live (~10:30–11 AM ET)
**Also crosspost to:** r/linux (same text, different timing — 60 min after r/netsec)

---

## Title

```
yubios: TPM-free Linux using YubiKey for Secure Boot, disk encryption, PAM auth, and SSH — full chain, no OEM trust anchor
```

## Body

```
Built this after hitting the Qualcomm fTPM wall on Surface ARM64 hardware — the TPM produces 
incorrect PCR measurements post-firmware-update, making TPM-based LUKS sealing unreliable. 
Rather than papering over it, I wanted a clean alternative: use the YubiKey as the only 
hardware root of trust across the entire stack.

**The security chain:**

1. **Secure Boot** — YubiKey PIV slot 9c signs the Unified Kernel Image via `sbsign --engine pkcs11`
   (CCID interface, not FIDO2/hidraw — toolchain limitation documented in ADR-002)

2. **LUKS2 disk unlock** — `systemd-cryptenroll --fido2-device=auto` binds the volume to a 
   FIDO2 credential stored on the key. No passphrase backup, no TPM PCR binding.

3. **PAM / sudo** — `pam-u2f` ≥1.3.1. Version floor is hard: CVE-2025-23013 (YSA-2025-01) 
   is a partial auth bypass in earlier versions via malformed credential files.

4. **SSH** — resident `ed25519-sk` keys via OpenSSH 8.2+. Private key material never 
   leaves the YubiKey. Onboarding script handles `ssh-keygen -t ed25519-sk -O resident`.

**Design decisions with ADRs:**

- FIDO2/hidraw handles runtime auth (disk, PAM, SSH); PIV/CCID handles Secure Boot signing.
  This is a toolchain boundary, not a security choice — sbsign doesn't speak HID.
- Bootc-style OCI image base: declarative `kargs.d/` for kernel args, immutable rootfs,
  `bootc upgrade` for day-2 patching.
- ARM64 Surface: upstream Fedora kernel packages (no linux-surface COPR needed on Snapdragon).
  x86 Surface uses linux-surface COPR for hardware driver coverage.

**Hardware tested:** Microsoft Surface Pro 11 (Snapdragon X Elite), Surface Pro 9 (i7)

GitHub: https://github.com/corning-croak-cable/yubios

The repo has full source citations and ADRs for every non-obvious choice. Questions on the 
threat model, the FIDO2/PIV boundary, or the ARM64 specifics welcome.
```

---

## r/linux variant title (post 60 min after r/netsec)

```
yubios: bootable Linux using YubiKey as root of trust — Secure Boot signing, LUKS, sudo, SSH (no TPM required)
```

r/linux body: same as above, no changes needed.
