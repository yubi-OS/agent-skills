# Social Thread

**Platform:** Twitter/X, Mastodon, Bluesky
**Post timing:** June 4, 2026 — same time as HN (9–10 AM ET)
**Format:** Thread (post 1 standalone, replies as thread)

---

## Thread

**Post 1 (standalone — must work without the rest):**
```
Launching yubios today: a bootable Linux where your YubiKey is the only root of trust.

No TPM. No OEM black box. Just a $50 hardware key you own.

github.com/corning-croak-cable/yubios

Thread on how the full chain works 🧵
```

**Post 2:**
```
Most Linux security builds the trust chain on TPM — a chip your OEM controls, with 
firmware you can't inspect, that doesn't even exist on a lot of ARM hardware.

YubiKeys are everywhere. They support exactly what we need. Nobody had wired them up 
to the whole stack. So we did.
```

**Post 3:**
```
The chain:

🔐 Secure Boot — YubiKey PIV slot signs the UKI via sbsign --engine pkcs11
💾 Disk unlock — FIDO2 via systemd-cryptenroll (tap to boot, no passphrase)
🔑 sudo/PAM — pam-u2f ≥1.3.1 (pinned: CVE-2025-23013 is a partial auth bypass in older versions)
🔒 SSH — resident ed25519-sk keys, private key never leaves the device
```

**Post 4:**
```
One design decision worth calling out:

Secure Boot signing goes through PIV/CCID (the smartcard interface).
Disk, PAM, and SSH go through FIDO2/hidraw.

This is a toolchain boundary, not a security choice — sbsign doesn't speak HID.
ADR-002 in the repo documents it.
```

**Post 5:**
```
Hardware: tested on Surface Pro 11 (Snapdragon X Elite ARM64) and Surface Pro 9 (x86).

The ARM64 story is actually cleaner — no linux-surface COPR needed, upstream Fedora 
kernel covers it. The x86 build needs the COPR for full hardware driver coverage.
```

**Post 6 (CTA):**
```
Full source, onboarding guide, and ADRs at:
github.com/corning-croak-cable/yubios

Questions on the FIDO2/PIV boundary, the threat model, or the ARM64 Surface support 
— reply here or open a GitHub Discussion.
```

---

## Mastodon / Bluesky variants

Same thread, remove the github.com shorthand and use full URL:
`https://github.com/corning-croak-cable/yubios`

On Mastodon: post to @linux@fosstodon.org and relevant security/infosec instances.

---

## LinkedIn (optional — general audience)

Single post, no thread:

```
Launching something today: yubios, a bootable Linux distro where your YubiKey handles 
everything — OS integrity verification, drive encryption, login auth, and SSH.

No TPM. No vendor lock-in. Works on any hardware with a USB port.

The idea: YubiKeys are pervasive in enterprise security but most operating systems 
treat them as 2FA-only. yubios shows what it looks like when you wire them to the 
full boot and auth stack.

Full source and onboarding guide: https://github.com/corning-croak-cable/yubios
```
