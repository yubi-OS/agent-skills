# Press Pitch

**Targets (in priority order):**
1. Phoronix — Michael Larabel (michael@phoronix.com)
2. LWN.net — Jon Corbet (corbet@lwn.net) — guest post angle, not just a news item
3. The Register — FOSS desk (letters@theregister.com)
4. Ars Technica — Hardware/Linux desk (submit via tips form)

**Send:** May 23, 2026 (under embargo until June 4 launch)
**Follow up:** May 30 if no response

---

## Email: Phoronix / The Register (news angle)

**Subject:** `yubios: open-source bootable Linux using YubiKey as full hardware root of trust — launch June 4`

```
Hi [name],

Quick tip — might be of interest to your readers.

On June 4 we're launching yubios, an open-source bootable Linux image that replaces 
TPM-based security with the YubiKey across the full stack: Secure Boot signing 
(PIV/CCID via sbsign), LUKS2 disk encryption (FIDO2 via systemd-cryptenroll), 
PAM authentication (pam-u2f ≥1.3.1), and resident SSH keys (ed25519-sk). 
No OEM trust anchor required.

The timing is relevant: ARM64 hardware (Microsoft Surface Snapdragon X Elite and 
similar) ships without a reliable TPM, and enterprise YubiKey deployments are 
pervasive — yet mainstream distributions still treat these devices as 2FA-only. 
yubios demonstrates what the full integration looks like.

A few details worth noting for technical coverage:
- The FIDO2/hidraw vs PIV/CCID boundary is a toolchain limitation, not a security choice 
  (documented in an ADR in the repo — sbsign doesn't speak HID)
- pam-u2f version floor at 1.3.1 is intentional: CVE-2025-23013 (YSA-2025-01) is a 
  partial auth bypass in earlier versions
- Tested on Surface Pro 11 Snapdragon X Elite and Surface Pro 9 x86

GitHub (going public June 4): https://github.com/corning-croak-cable/yubios

Happy to answer technical questions or provide early access to the repo under embargo.

[name]
```

---

## Email: LWN.net (guest post / feature angle)

**Subject:** `Guest post pitch: YubiKey as a full Linux security root of trust — walk-through and analysis`

```
Hi Jon,

LWN pitch — a technical walkthrough piece rather than a straight news item.

The piece: "Beyond 2FA: using the YubiKey as Linux's complete root of trust"

Walk-through of how FIDO2, PIV/CCID, and resident key features combine across 
Secure Boot (sbsign + PKCS#11), LUKS2 (systemd-cryptenroll), PAM (pam-u2f), 
and SSH (ed25519-sk resident keys) — using yubios as the reference implementation.

The piece would cover:
1. Why the FIDO2/hidraw and PIV/CCID interfaces serve different roles (and why this matters)
2. The pam-u2f 1.3.1 CVE floor and what it means for distributions shipping older versions
3. The bootc architecture choice: OCI image-based, declarative kargs.d, immutable rootfs
4. ARM64 considerations: Qualcomm fTPM unreliability and why USB-based roots of trust 
   are better positioned for this hardware generation

yubios launches June 4. Happy to write this up as a proper technical article, or provide 
a briefing for your own coverage.

[name]
```

---

## Follow-up (send May 30 if no response)

**Subject:** `Re: yubios launch June 4 — quick follow-up`

```
Hi [name],

Following up on my note from May 23 about the yubios launch on June 4.

If you're interested in early access to the repo or have technical questions 
before the embargo lifts, I'm happy to set up a call or answer via email.

[name]
```
