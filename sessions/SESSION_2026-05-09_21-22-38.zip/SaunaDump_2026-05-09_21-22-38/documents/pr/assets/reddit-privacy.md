# Reddit Post: r/privacy

**Subreddit:** r/privacy
**Post timing:** June 4, 2026 — 2 hours after HN (~12–1 PM ET)
**Also consider:** r/linuxhardware, r/hardware, r/yubikey

---

## Title

```
I built a Linux distro that uses your YubiKey for everything: proving the OS wasn't tampered with, unlocking your drive, logging in, and keeping SSH keys off-disk entirely
```

## Body

```
If you own a YubiKey — even the basic $25 Security Key — you have better hardware security 
than most computers ship with. Most operating systems use it only for website 2FA. That's 
barely scratching the surface.

**yubios uses it for the whole chain:**

🔐 **Boot integrity** — Before the OS loads, your YubiKey signs the boot image. If anyone 
modified the kernel or boot process, it won't boot. No OEM chip involved.

💾 **Drive encryption** — Your encrypted drive only unlocks when you physically plug in your 
YubiKey and tap it. The passphrase doesn't exist — there's nothing to phish, leak, or forget.

🔑 **App auth and sudo** — Instead of typing a password for admin tasks, you tap your YubiKey. 
Works for anything that uses Linux PAM (sudo, screen unlock, polkit).

🔒 **SSH keys that can't be stolen** — Your SSH private key lives inside the YubiKey hardware. 
Even if someone fully compromises your laptop, they can't extract the key. They'd need the 
physical device in hand.

**Why this matters:**

Most "secure" Linux setups rely on TPM chips — a piece of hardware your OEM controls, with 
firmware you can't inspect, that doesn't exist on a lot of ARM laptops. yubios replaces all 
of that with a $25-$80 device you already own, auditable open-source tooling, and no vendor lock-in.

Runs on regular hardware including Microsoft Surface. Step-by-step onboarding — you don't 
need to understand FIDO2 or PIV to get started.

GitHub + onboarding guide: https://github.com/corning-croak-cable/yubios

Happy to answer questions on how this compares to standard LUKS setups or what 
happens if you lose the key.
```

---

## r/yubikey variant title

```
Built a bootable Linux distro that uses the YubiKey for the full security chain — not just 2FA
```

Body: same as above, trim the "why this matters" section since the audience already knows what YubiKeys do.
