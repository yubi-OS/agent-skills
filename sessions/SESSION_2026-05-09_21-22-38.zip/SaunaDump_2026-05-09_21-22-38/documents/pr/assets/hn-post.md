# HN: Show HN Post

**Target:** news.ycombinator.com
**Post type:** Show HN
**Best time:** Thursday June 4, 2026 — 9–11 AM ET
**Character limit:** None (but keep body under 400 words — HN readers skim)

---

## Title

```
Show HN: yubios – bootable Linux where the YubiKey is the only root of trust (no TPM)
```

## Body

```
Most Linux security setups still treat the TPM as the hardware anchor — but TPM is OEM-controlled, a black box, and often absent on ARM64 hardware (Surface Snapdragon, etc.). YubiKeys are already everywhere in enterprise and support exactly what's needed:

- Secure Boot key custody: PIV/CCID interface, signing via `sbsign --engine pkcs11`
- Disk encryption: FIDO2 via `systemd-cryptenroll --fido2-device=auto` — no passphrase backup that can leak
- App auth / sudo: `pam-u2f` ≥1.3.1 (floor set due to CVE-2025-23013 / YSA-2025-01)
- SSH: resident `ed25519-sk` keys — private key never touches disk

The design borrows from bootc (OCI image-based, declarative `kargs.d`) and ParticleOS (immutable root, clean boot-time security model). Every non-obvious decision — including the FIDO2/hidraw vs PIV/CCID boundary, the Qualcomm ARM64 fTPM workaround, and the pam-u2f CVE floor — has a source citation or ADR in the repo.

Hardware support: x86_64 and ARM64 (Microsoft Surface Snapdragon Elite X). Works on anything with a USB port and a YubiKey.

GitHub: https://github.com/corning-croak-cable/yubios

Happy to get into the FIDO2/PIV boundary, the Secure Boot UKI flow, or the ARM64 Surface specifics.
```

---

## Expected conversation threads

Prepare answers for these likely comment directions:

**"Why not TPM?"**
> TPM is OEM-controlled and opaque. On ARM64 hardware like the Surface Snapdragon, the Qualcomm fTPM has known issues (incorrect PCR measurements post-firmware-update, partial fTPM availability depending on OEM). YubiKey gives you hardware attestation you physically own and can audit the firmware of.

**"What if you lose the YubiKey?"**
> Same answer as any hardware token: keep a backup key enrolled, or a recovery passphrase in offline cold storage. This is documented in the onboarding guide. The threat model accepts "lost key = locked out" as a feature, not a bug — you can't have both maximum security and "I forgot my password, reset it."

**"pam-u2f seems fragile for sudo"**
> Valid concern. The CVE-2025-023013 fix in ≥1.3.1 closes the partial auth bypass. We also recommend keeping a fallback root console accessible during initial setup. Not designed for zero-recovery environments.

**"Does this work without physical YubiKey on every boot?"**
> No. That's intentional — this is for users who want hardware presence enforced on every boot. If you want convenience over security, this isn't the distro.
